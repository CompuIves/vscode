/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import * as jsonc from 'jsonc-parser';
import { dirname, join } from 'path';
import * as vscode from 'vscode';
import { flatten } from '../utils/arrays';

function mapNode<R>(node: jsonc.Node | undefined, f: (x: jsonc.Node) => R): R[] {
	return node && node.type === 'array' && node.children
		? node.children.map(f)
		: [];
}

class TsconfigLinkProvider implements vscode.DocumentLinkProvider {

	public provideDocumentLinks(
		document: vscode.TextDocument,
		_token: vscode.CancellationToken
	): vscode.ProviderResult<vscode.DocumentLink[]> {
		const root = jsonc.parseTree(document.getText());
		if (!root) {
			return null;
		}

		return [
			this.getExendsLink(document, root),
			...this.getFilesLinks(document, root),
			...this.getReferencesLinks(document, root)
		].filter(x => !!x) as vscode.DocumentLink[];
	}

	private getExendsLink(document: vscode.TextDocument, root: jsonc.Node): vscode.DocumentLink | undefined {
		return this.pathNodeToLink(document, jsonc.findNodeAtLocation(root, ['extends']));
	}

	private getFilesLinks(document: vscode.TextDocument, root: jsonc.Node) {
		return mapNode(
			jsonc.findNodeAtLocation(root, ['files']),
			node => this.pathNodeToLink(document, node));
	}

	private getReferencesLinks(document: vscode.TextDocument, root: jsonc.Node) {
		return mapNode(
			jsonc.findNodeAtLocation(root, ['references']),
			child => this.pathNodeToLink(document, jsonc.findNodeAtLocation(child, ['path'])));
	}

	private pathNodeToLink(
		document: vscode.TextDocument,
		node: jsonc.Node | undefined
	): vscode.DocumentLink | undefined {
		return this.isPathValue(node)
			? new vscode.DocumentLink(this.getRange(document, node), this.getTarget(document, node))
			: undefined;
	}

	private isPathValue(extendsNode: jsonc.Node | undefined): extendsNode is jsonc.Node {
		return extendsNode
			&& extendsNode.type === 'string'
			&& extendsNode.value
			&& !(extendsNode.value as string).includes('*');
	}

	private getTarget(document: vscode.TextDocument, node: jsonc.Node): vscode.Uri {
		return vscode.Uri.file(join(dirname(document.uri.fsPath), node!.value));
	}

	private getRange(document: vscode.TextDocument, node: jsonc.Node) {
		const offset = node!.offset;
		const start = document.positionAt(offset + 1);
		const end = document.positionAt(offset + (node!.length - 1));
		return new vscode.Range(start, end);
	}
}

export function register() {
	const patterns: vscode.GlobPattern[] = [
		'**/[jt]sconfig.json',
		'**/[jt]sconfig.*.json',
	];

	const languages = ['json', 'jsonc'];

	const selector: vscode.DocumentSelector = flatten(
		languages.map(language =>
			patterns.map((pattern): vscode.DocumentFilter => ({ language, pattern }))));

	return vscode.languages.registerDocumentLinkProvider(selector, new TsconfigLinkProvider());
}
